package com.mycompany.pruebacajacompleja;

public class CajaCompleja {
    // Datos para un cliente
    public double importeCliente;
    public int numArticulosCliente;
    
    // Acumuladores totales
    public int numClientesAtendidos;
    public double importeTotalCaja;
    public int numArticulosVendidos;
    
    
    public void abrirCaja() {
        importeCliente = 0;
        numArticulosCliente = 0;
        numClientesAtendidos = 0;
        importeTotalCaja = 0;
        numArticulosVendidos = 0;
    }
    
    public void nuevoCliente() {
        // Inicializamos los datos de cliente (porque llega un cliente nuevo).
        importeCliente = 0;
        numArticulosCliente = 0;
        
        // Como llega un cliente nuevo, lo cuento:
        numClientesAtendidos++;
    }
    
    public void registrarArticulo (double precio) {
        // Para este cliente, actualizo sus datos particulares:
        numArticulosCliente++;
        importeCliente += precio;
        
        // Tengo en cuenta el registro del artículo para actualizar los acumulados:
        numArticulosVendidos++;
        importeTotalCaja += precio;
    }
    
    public void anularArticulo (double precio) {
        // Para este cliente, actualizo sus datos particulares
        numArticulosCliente--;
        importeCliente -= precio;
        
        // // Tengo en cuenta el registro del artículo para actualizar los acumulados:
        numArticulosVendidos--;
        importeTotalCaja -= precio;
    }
    
    public void imprimirTicketCliente() {
        System.out.println("El cliente ha comprado " + numArticulosCliente +
                           " artículos por un precio total de " + importeCliente + " euros.");
    }
    
    public void imprimeCierreCaja() {
        System.out.println("Se han vendido un total de " + numArticulosVendidos + 
                           " artículos por un importe total de " + importeTotalCaja + " euros.");
    }
    
    public double calculaPrecioMedioArticulosVendidos() {
        return importeTotalCaja / numArticulosVendidos;
    }
    
    public double calculaImporteMedioPorCliente() {
        return importeTotalCaja / numClientesAtendidos;
    }
}
