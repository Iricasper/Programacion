package es.marca.futbol.jugadores;

public class Futbolista {

    public String nombre, apellidos;
    public int numGoles;
    public double salario;
    public boolean lesionado;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nuevoNombre) {
        nombre = nuevoNombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String nuevoApellidos) {
        apellidos = nuevoApellidos;
    }

    public int getNumGoles() {
        return numGoles;
    }

    public void setNumGoles(int nuevoNumGoles) {
        numGoles = nuevoNumGoles;
    }

    public double getSalario() {
        return salario;
    }
    
    public boolean isLesionado() {
        return lesionado;
    }

    public void setSalario(double nuevoSalario) {
        salario = nuevoSalario;
    }

    public void marcaGol(int numGolesMarcados) {
        numGoles = numGoles + numGolesMarcados;
    }


    public void golAnulado() {
        numGoles--;
    }

    public void seLesiona() {
        lesionado = true;
    }

    public void seRecupera() {
        lesionado = false;
    }

}
