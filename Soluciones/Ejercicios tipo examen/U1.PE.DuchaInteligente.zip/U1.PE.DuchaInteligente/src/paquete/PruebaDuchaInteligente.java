package paquete;

import paquete.DuchaInteligente;

public class PruebaDuchaInteligente {
    public static void main(String[] args) {
        DuchaInteligente d = new DuchaInteligente();
        
        d.setTemperatura(35);
        d.setLitrosPorSegundo(1);
        d.activarUnTiempo(20);
        d.subeTemperatura();
        d.subeTemperatura();
        d.setLitrosPorSegundo(1.5);
        d.activarUnTiempo(280);
        d.desactivar();
        System.out.println("------");
        
        d.imprimeEstadoDucha();
        
        System.out.println("------");
        d.setLitrosPorSegundo(2);
        d.activarUnTiempo(100);
        d.bajaTemperatura();
        d.activarUnTiempo(80);
        d.desactivar();
        
        System.out.println("------");
        int numVeces = d.getNumVecesUtilizada();
        double litros = d.getTotalLitrosGastados();
        double promedio = litros / numVeces;
        System.out.println("En cada ducha gastas un promedio de "+promedio+" litros");
        
    }
}
