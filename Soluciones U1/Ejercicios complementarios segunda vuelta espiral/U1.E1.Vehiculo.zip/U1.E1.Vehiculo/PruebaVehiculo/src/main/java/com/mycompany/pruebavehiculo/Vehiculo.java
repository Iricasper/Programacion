package com.mycompany.pruebavehiculo;

public class Vehiculo {
    public int numRuedas;
    public double potencia;
    public double litrosEnDeposito;
    public double consumoPor100Km;
    public boolean arrancado;
    // No viene en el enunciado:
    public double kmRecorridos;
    
    public void setNumRuedas (int nuevoNumRuedas) {
        numRuedas = nuevoNumRuedas;
    }
    
    public void setPotencia (double nuevaPotencia) {
        potencia = nuevaPotencia;
    }
    
    public void setConsumoPor100Km (double nuevoConsumoPor100Km) {
        consumoPor100Km = nuevoConsumoPor100Km;
    }
    
    public void reponerCombustible (double numLitrosRepuesto) {
        litrosEnDeposito = litrosEnDeposito + numLitrosRepuesto;
    }
    
    public void recorrerDistancia (double numKm) {
        litrosEnDeposito = litrosEnDeposito - (numKm * consumoPor100Km / 100);
        kmRecorridos = kmRecorridos + numKm;
    }
    
    public void arrancar() {
        arrancado = true;
    }
    
    public void apagar() {
        arrancado = false;
    }
    
    public int getNumRuedas() {
        return numRuedas;
    }
    
    public double getPotencia() {
        return potencia;
    }
    
    public double getConsumoPor100Km() {
        return consumoPor100Km;
    }
    
    public double getLitrosEnDeposito() {
        return litrosEnDeposito;
    }
    
    public double calculaPorcentajeDesgaste() {
        // Falta un dato en el enunciado (ver atributos)
        return kmRecorridos * 100 / 200000;
    }
}
