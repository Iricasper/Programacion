package com.mycompany.pruebacajacompleja;

public class PruebaCajaCompleja {

    public static void main(String[] args) {
        CajaCompleja caja = new CajaCompleja();
        
        // Operaciones tipo caja.XXXXXX
        caja.abrirCaja();
        caja.nuevoCliente();
        caja.registrarArticulo(10.75);
        caja.registrarArticulo(4.32);
        caja.imprimirTicketCliente();
        caja.anularArticulo(4.32);
        caja.imprimirTicketCliente();
        
        caja.nuevoCliente();
        caja.registrarArticulo(2.24);
        caja.registrarArticulo(1.87);
        caja.registrarArticulo(10.12);
        caja.imprimirTicketCliente();
        
        System.out.println("\nImporte medio por cliente: " + 
                           caja.calculaImporteMedioPorCliente());
        System.out.println("Precio medio de los artículos vendidos: " +
                           caja.calculaPrecioMedioArticulosVendidos());
    }
}
