package com.mycompany.pruebarelojdespertador;

public class PruebaRelojDespertador {

    public static void main(String[] args) {
        RelojDespertador r = new RelojDespertador();
        
        // Operaciones tipo r.XXXXXX
    }
}
