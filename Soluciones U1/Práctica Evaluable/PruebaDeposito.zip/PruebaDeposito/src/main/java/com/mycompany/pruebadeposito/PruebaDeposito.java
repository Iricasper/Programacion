package com.mycompany.pruebadeposito;

public class PruebaDeposito {

    public static void main(String[] args) {
        DepositoCircular dep = new DepositoCircular();
        
        double perimetro, superficie, capacidad;
        
        dep.estableceRadio(1.5);
        dep.estableceAltura(3);
        dep.estableceGastoLitrosPorHora(1000);
        dep.estableceNumLitrosActual(1000);
        
        dep.imprimeRadio();
        dep.imprimeAltura();
        dep.imprimeGastoLitrosPorHora();
        dep.imprimeNumLitrosActual();
        
        System.out.println("");
        
        dep.cargaDeposito(4000);
        
        dep.riega(90);
        
        dep.imprimeRadio();
        dep.imprimeAltura();
        dep.imprimeGastoLitrosPorHora();
        dep.imprimeNumLitrosActual();
        
        System.out.println("");
        
        perimetro = dep.calculaPerimetroBase();
        System.out.println("Perímetro = " + perimetro);
        superficie = dep.calculaSuperficieBase();
        System.out.println("Superficie = " + superficie);
        capacidad = dep.calculaCapacidad();
        System.out.println("Capacidad = " + capacidad);
    }
}
