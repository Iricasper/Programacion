package com.mycompany.pruebadeposito;

public class DepositoCircular {
    public double radio;
    public double altura;
    public double gastoLitrosPorHora;
    public double numLitrosActual;
    
    public void imprimeRadio() {
        System.out.println("Radio = " + radio);
    }
    
    public void imprimeAltura() {
        System.out.println("Altura = " + altura);
    }
    
    public void imprimeGastoLitrosPorHora() {
        System.out.println("Gasto litros por hora = " + gastoLitrosPorHora);
    }
    
    public void imprimeNumLitrosActual() {
        System.out.println("Número litros actual = " + numLitrosActual);
    }
    
    public void estableceRadio (double valor) {
        radio = valor;
    }
    
    public void estableceAltura (double valor) {
        altura = valor;
    }
    
    public void estableceGastoLitrosPorHora (double valor) {
        gastoLitrosPorHora = valor;
    }
    
    public void estableceNumLitrosActual (double valor) {
        numLitrosActual = valor;
    }
    
    public double calculaSuperficieBase() {
        return Math.PI * radio * radio;
    }
    
    public double calculaPerimetroBase() {
        return 2 * Math.PI * radio;
    }
    
    public double calculaCapacidad() {
        return calculaSuperficieBase() * altura * 1000;
    }
    
    public void cargaDeposito (double numLitros) {
        numLitrosActual = numLitrosActual + numLitros;
    }
    
    public void riega (double numMinutos) {
        numLitrosActual = numLitrosActual - (numMinutos * gastoLitrosPorHora / 60);
    }
}
