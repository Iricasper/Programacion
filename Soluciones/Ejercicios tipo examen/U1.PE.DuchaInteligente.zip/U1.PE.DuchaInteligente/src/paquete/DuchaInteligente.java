package paquete;

public class DuchaInteligente {

    public int numVecesUtilizada;
    public double litrosGastados, totalLitrosGastados, litrosPorSegundo;
    public double temperatura;
    public boolean activa;

    public void setLitrosPorSegundo(double nuevoLitrosPorSegundo) {
        litrosPorSegundo = nuevoLitrosPorSegundo;
    }

    public void setTemperatura(double nuevaTemp) {
        temperatura = nuevaTemp;
    }

    public void subeTemperatura() {
        temperatura = temperatura + 0.5;
    }

    public void bajaTemperatura() {
        temperatura = temperatura - 0.5;
    }

    public int getNumVecesUtilizada() {
        return numVecesUtilizada;
    }

    public double getTotalLitrosGastados() {
        return totalLitrosGastados;
    }

    public void imprimeEstadoDucha() {
        System.out.println("ESTADO: Activa = " + activa + ". Temperatura = " + temperatura + "º. Caudal = " + litrosPorSegundo + " litros/seg");
    }

    public void activarUnTiempo(double segundos) {
        activa = true;
        double gasto = litrosPorSegundo * segundos;
        litrosGastados = litrosGastados + gasto;
        totalLitrosGastados = totalLitrosGastados + gasto;
    }

    public void desactivar() {
        activa = false;
        numVecesUtilizada++;
        System.out.println("Acabas de gastar " + litrosGastados + " litros");
        System.out.println("Estadísticas: has usado la ducha " + numVecesUtilizada + " veces y has gastado un total de " + totalLitrosGastados + " litros");
        litrosGastados = 0;
    }
}
