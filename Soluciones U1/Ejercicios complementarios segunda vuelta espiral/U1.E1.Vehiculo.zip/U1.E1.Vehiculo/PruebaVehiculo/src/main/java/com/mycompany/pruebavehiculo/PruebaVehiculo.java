package com.mycompany.pruebavehiculo;

public class PruebaVehiculo {

    public static void main(String[] args) {
        Vehiculo seat = new Vehiculo();
        
        // operaciones tipo seat.xxxxx
    }
}
