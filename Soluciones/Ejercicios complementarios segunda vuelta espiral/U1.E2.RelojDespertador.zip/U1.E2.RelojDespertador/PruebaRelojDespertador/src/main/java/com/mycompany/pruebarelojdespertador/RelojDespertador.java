package com.mycompany.pruebarelojdespertador;

public class RelojDespertador {
    public int horaReloj;
    public int minutosReloj;
    public int horaAlarma;
    public int minutosAlarma;
    public boolean alarmaActiva;
    
    public void setHora (int hora, int minutos) {
        horaReloj = hora;
        minutosReloj = minutos;
    }
    
    public void setHoraAlarma (int horaAlarm, int minAlarm) {
        horaAlarma = horaAlarm;
        minutosAlarma = minAlarm;
    }
    
    public int getHoraActual() {
        return horaReloj;
    }
    
    public int getMinutoActual() {
        return minutosReloj;
    }
    
    public int getHoraAlarma() {
        return horaAlarma;
    }
    
    public int getMinutoAlarma() {
        return minutosAlarma;
    }
    
    public void activarAlarma() {
        alarmaActiva = true;
    }
    
    public void desactivarAlarma() {
        alarmaActiva = false;
    }
    
    public void sonarAlarma() {
        System.out.println("NA NA NA NA NA NA NA");
    }
    
    public void imprimirHoraActual() {
        System.out.println("Son las " + horaReloj + ":" + minutosReloj);
    }
    
    public void imprimirHoraAlarma() {
        System.out.println("La alarma está configurada para sonar a las " +
                           horaAlarma + ":" + minutosAlarma);
    }
    
    public void imprimirEstadoAlarma() {
        System.out.println("La alarma está encendida?: " + alarmaActiva);
    }
}
